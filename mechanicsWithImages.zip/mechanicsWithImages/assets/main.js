let currentRows, currentCols;

function startGame(rows, cols) {
    currentRows = rows;
    currentCols = cols;

    document.getElementById('home').style.display = 'none';
    document.getElementById('gamePage').style.display = 'block';

    const totalCards = rows * cols;
    if (totalCards % 2 !== 0) {
        return;
    }

    const gameBoard = document.getElementById("gameBoard");
    gameBoard.innerHTML = "";
    gameBoard.style.gridTemplateColumns = `repeat(${cols}, 80px)`;
    gameBoard.style.gridTemplateRows = `repeat(${rows}, 100px)`;

    // Array of image paths
    const images = [
        "./assets/images/apple.jpg",
        "./assets/images/orange.jpg",
        "./assets/images/lemon.jpeg",
        "./assets/images/mango.jpg",
        "./assets/images/peach.jpg",
        "./assets/images/avocado.jpg",
        "./assets/images/pear.jpg",
        "./assets/images/kiwi.jpg",
        "./assets/images/strawberry.jpeg",
        "./assets/images/melon.jpg"
    ];

    const img = images;
    console.log(img)

    let cardValues = [];
    for (let i = 0; i < totalCards / 2; i++) {
        cardValues.push(images[i]);
        cardValues.push(images[i]);
    }

    cardValues = cardValues.sort(() => Math.random() - 0.5);

    let selectedCards = [];
    let matchedCards = [];
    let cards = [];

    for (let value of cardValues) {
        const card = document.createElement("div");
        card.classList.add("card");
        card.dataset.value = value;

        const cardInner = document.createElement("div");
        cardInner.classList.add("card-inner");

        const cardFront = document.createElement("div");
        cardFront.classList.add("card-front");
        cardFront.innerText = "?"; // Keeps the front design

        const cardBack = document.createElement("div");
        cardBack.classList.add("card-back");

        // Set the image as the background of the card-back
        const img = document.createElement("img");
        img.src = value;
        img.alt = "Card Image";
        img.style.width = "100%";
        img.style.height = "100%";
        cardBack.appendChild(img);

        cardInner.appendChild(cardFront);
        cardInner.appendChild(cardBack);
        card.appendChild(cardInner);

        cards.push(card);
        card.classList.add("flipped"); 

        card.addEventListener("click", function () {
            if (matchedCards.includes(card) || selectedCards.includes(card)) return;

            card.classList.add("flipped");
            selectedCards.push(card);

            if (selectedCards.length === 2) {
                setTimeout(() => {
                    if (selectedCards[0].dataset.value === selectedCards[1].dataset.value) {
                        selectedCards.forEach(c => c.classList.add("matched"));
                        matchedCards.push(...selectedCards);
                    } else {
                        selectedCards.forEach(c => c.classList.remove("flipped"));
                    }
                    selectedCards = [];
                    
                    if (matchedCards.length === totalCards) {
                        setTimeout(showWinPopup, 500);
                    }
                }, 1000);
            }
        });

        gameBoard.appendChild(card);
    }

    setTimeout(() => {
        cards.forEach(card => card.classList.remove("flipped"));
    }, 2000);
}

function showWinPopup() {
    let popup = document.getElementById('winPopupContainer');
    popup.style.display = 'flex';
}

function exitGame() {
    document.getElementById('winPopupContainer').style.display = 'none';
    goBack();
}

function nextLevel() {
    document.getElementById('winPopupContainer').style.display = 'none';

    if (currentRows <= currentCols) {
        currentRows++;
    } else {
        currentCols++;
    }

    startGame(currentRows, currentCols+1);
}


function goBack() {
    document.getElementById('home').style.display = 'flex';
    document.getElementById('gamePage').style.display = 'none';
}
