let currentRows, currentCols, currentGame, currentLevel = 1;
const rewards = { game1: [], game2: [], game3: [], game4: [] };

// Timer variables
let timerInterval, elapsedTime = 0;

// Move counter variable
let moveCount = 0;

// Basket tracking
let basketIndex = 0; // Tracks which basket to use (0 or 1)

function openPopup() {
    const popup = document.getElementById('popup');
    if (popup) {
        popup.style.display = 'flex';
        popup.style.zIndex = '1000';
    } else {
        console.error('Popup element not found');
    }
}

function closePopup() {
    const popup = document.getElementById('popup');
    if (popup) {
        popup.style.display = 'none';
    }
}

function showFarmSelection() {
    console.log('showFarmSelection called');
    
    // Hide all game pages
    const gamePages = ['game1Page', 'game2Page', 'game3Page', 'game4Page'];
    gamePages.forEach(pageId => {
        const page = document.getElementById(pageId);
        if (page) page.style.display = 'none';
    });
    
    // Hide game board if visible
    const gameBoard = document.getElementById('gameBoardContainer');
    if (gameBoard) gameBoard.style.display = 'none';
    
    // Hide landing page
    const landingPage = document.getElementById('landingPage');
    if (landingPage) landingPage.style.display = 'none';
    
    // Close all popups
    const popups = ['popup', 'winPopupContainer', 'finalWinPopupContainer'];
    popups.forEach(popupId => {
        const popup = document.getElementById(popupId);
        if (popup) popup.style.display = 'none';
    });
    
    // Show farm selection page
    const farmSelectionPage = document.getElementById('farmSelectionPage');
    if (farmSelectionPage) {
        farmSelectionPage.style.display = 'flex';
        console.log('Navigation to farm selection completed');
    } else {
        console.error('Farm selection page not found');
    }
}

// Function to animate clouds
function animateClouds(svgDoc) {
    // Only animate if this is the title SVG
    if (!svgDoc.getElementById('cloud1') && !svgDoc.getElementById('cloud-2')) {
        return; // Skip animation for non-title SVGs
    }
    
    console.log('Starting cloud animation');
    
    // Find all cloud elements by their IDs
    const cloudIds = ['cloud1', 'cloud2', 'cloud3'];
    const clouds = cloudIds.map(id => svgDoc.getElementById(id)).filter(Boolean);
    
    // Define properties for each cloud
    const cloudConfig = {
        cloud1: {
            speed: 40,
            startX: -500,
            resetX: -1500  // Far left reset position
        },
        cloud2: {
            speed: 40,
            startX: -800,
            resetX: -1800  // Far left reset position
        },
        cloud3: {
            speed: 40,
            startX: -1100,
            resetX: -2100  // Far left reset position
        }
    };
    
    console.log('Found clouds:', clouds.length);
    console.log('Cloud elements:', clouds);
    
    const screenWidth = window.innerWidth;
    
    // Position and animate each cloud
    clouds.forEach((cloud) => {
        const config = cloudConfig[cloud.id];
        
        function moveCloud() {
            // First set to reset position
            gsap.set(cloud, { x: config.resetX });
            
            // Then animate to right edge
            gsap.to(cloud, {
                x: screenWidth + 100,   // Move to right edge
                duration: config.speed,  // Individual speed
                ease: 'none',
                onComplete: moveCloud    // Restart when done
            });
        }
        
        // Set initial position and start animation
        gsap.set(cloud, { x: config.startX });
        moveCloud();
    });
}

// Handle farm selection SVG interactions
function initFarmSelection() {
    const farmSvg = document.getElementById('farmSelectionSvg');
    
    farmSvg.addEventListener('load', function() {
        const svgDoc = farmSvg.contentDocument;
        
        // Farm IDs in the SVG
        const farmIds = ['spring-farm', 'summer-farm', 'fall-farm', 'winter-farm'];
        const gameMapping = {
            'spring-farm': 'game1',
            'summer-farm': 'game2',
            'fall-farm': 'game4',
            'winter-farm': 'game3'
        };
        
        // Add click handlers to each farm
        farmIds.forEach(farmId => {
            const farmElement = svgDoc.getElementById(farmId);
            if (farmElement) {
                farmElement.style.cursor = 'pointer';
                farmElement.addEventListener('click', () => {
                    const gameId = gameMapping[farmId];
                    goToGame(gameId);
                });
            }
        });
    });
}


// Add event listener for SVG buttons
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM Content Loaded');
    const svgObject = document.getElementById('titleSvg');
    console.log('SVG Object:', svgObject);
    
    if (svgObject) {
        svgObject.addEventListener('load', function() {
            const svgDoc = svgObject.contentDocument;
            initializeSVGButtons(svgDoc);
        });
    }
    
    // Handle farm selection SVG
    const farmSvg = document.getElementById('farmSelectionSvg');
    console.log('Farm SVG Object:', farmSvg);
    
    if (farmSvg) {
        farmSvg.addEventListener('load', function() {
            console.log('Farm SVG loaded');
            const svgDoc = farmSvg.contentDocument;
            
            if (svgDoc) {
                // Debug: Log all elements to see what we have
                const allElements = Array.from(svgDoc.getElementsByTagName('*'));
                console.log('All SVG elements:', allElements.map(el => ({ id: el.id, tagName: el.tagName })));
                
                // Farm mappings (autumn -> game1, summer -> game2, winter -> game3, spring -> game4)
                const farmMappings = {
                    'autumn': 'game1',
                    'summer': 'game2',
                    'winter': 'game3',
                    'spring': 'game4'
                };
                
                // Find all elements that might be part of each farm
                Object.keys(farmMappings).forEach(farmName => {
                    // Try different possible ID patterns
                    const possibleSelectors = [
                        `#${farmName}`,
                        `#${farmName}-farm`,
                        `#${farmName}_farm`,
                        `[id*="${farmName}"]`,
                        `[class*="${farmName}"]`
                    ];
                    
                    // Try each selector
                    possibleSelectors.forEach(selector => {
                        const elements = svgDoc.querySelectorAll(selector);
                        elements.forEach(element => {
                            console.log(`Found ${farmName} element:`, element);
                            
                            // Make element and its children clickable
                            element.style.cursor = 'pointer';
                            element.style.pointerEvents = 'all';
                            
                            // Add click handler
                            element.addEventListener('click', function(e) {
                                console.log(`${farmName} farm clicked, going to ${farmMappings[farmName]}`);
                                e.preventDefault();
                                e.stopPropagation();
                                goToGame(farmMappings[farmName]);
                            });
                        });
                    });
                });
            } else {
                console.error('Could not access SVG document');
            }
        });
    } else {
        console.error('Farm SVG not found in document');
    }
    
    function initializeSVGButtons(svgDoc) {
        console.log('Initializing SVG buttons');
        
        // Function to check if an element is within the button areas
        function isInButtonArea(element) {
            try {
                const rect = element.getBoundingClientRect();
                const svgRect = svgDoc.documentElement.getBoundingClientRect();
                const relativeY = (rect.top - svgRect.top) / svgRect.height;
                
                // Button areas are typically in the middle-bottom portion of the SVG
                // Adjust these values based on your specific SVG layout
                return relativeY > 0.4 && relativeY < 0.8;
            } catch (e) {
                return false;
            }
        }
        
        // Find all potential button elements
        const buttonElements = svgDoc.querySelectorAll('rect, text');
        console.log('Found potential button elements:', buttonElements.length);
        
        buttonElements.forEach((element, index) => {
            if (isInButtonArea(element)) {
                console.log(`Making element ${index} interactive:`, element);
                
                // Make element interactive
                element.style.cursor = 'pointer';
                element.style.pointerEvents = 'all';
                
                // Add click handler
                element.addEventListener('click', function(e) {
                    console.log('Button clicked:', this);
                    e.preventDefault();
                    e.stopPropagation();
                    
                    const rect = this.getBoundingClientRect();
                    const svgRect = svgDoc.documentElement.getBoundingClientRect();
                    const relativeY = (rect.top - svgRect.top) / svgRect.height;
                    
                    // Determine which button was clicked based on position
                    if (relativeY < 0.6) {
                        console.log('Play button clicked');
                        showFarmSelection();
                    } else if (relativeY >= 0.6) {
                        console.log('How to Play button clicked');
                        openPopup();
                    }
                });
                
                // Add hover effects
                element.addEventListener('mouseover', function() {
                    this.style.opacity = '0.8';
                });
                
                element.addEventListener('mouseout', function() {
                    this.style.opacity = '1';
                });
            } else {
                // Ensure non-button elements are not interactive
                element.style.pointerEvents = 'none';
                element.style.cursor = 'default';
            }
        });
    }
    
    // Handle SVG load
    svgObject.addEventListener('load', function() {
        console.log('SVG loaded');
        const svgDoc = svgObject.contentDocument;
        if (svgDoc) {
            console.log('SVG document found');
            initializeSVGButtons(svgDoc);
            // Start cloud animation
            animateClouds(svgDoc);
        } else {
            console.error('No SVG document found');
        }
    });
    
    // Check if SVG is already loaded
    if (svgObject.contentDocument && svgObject.contentDocument.readyState === 'complete') {
        console.log('SVG already loaded');
        initializeSVGButtons(svgObject.contentDocument);
    }
});

function goToGame(game) {
    document.getElementById('farmSelectionPage').style.display = 'none';
    document.getElementById(`${game}Page`).style.display = 'block';
    currentGame = game;
}

function goBackToLanding() {
    document.querySelectorAll('.game-page').forEach(page => page.style.display = 'none');
    document.getElementById('farmSelectionPage').style.display = 'flex';
    document.getElementById('landingPage').style.display = 'flex';
    document.getElementById('winPopupContainer').style.display = 'none';
    document.getElementById('finalWinPopupContainer').style.display = 'none';
    currentGame = null;
    currentLevel = 1;
    resetGameStats();
}

function startGame(rows, cols, game, level) {
    currentRows = rows;
    currentCols = cols;
    currentGame = game;
    currentLevel = level;

    // Reset game stats for new level
    resetGameStats();

    document.getElementById(`${game}Page`).style.display = 'none';
    document.getElementById('gameBoardContainer').style.display = 'block';

    const totalCards = rows * cols;
    if (totalCards % 2 !== 0) return;

    const gameBoard = document.getElementById("gameBoard");
    gameBoard.innerHTML = "";
    gameBoard.style.gridTemplateColumns = `repeat(${cols}, 100px)`;
    gameBoard.style.gridTemplateRows = `repeat(${rows}, 130px)`;
    gameBoard.style.gap = "15px";

    // Define season-specific image sets
    const seasonImages = {
        game1: [ // Spring farm images
            "./assets/images/spring/tulip.jpg",
            "./assets/images/spring/daffodil.jpg",
            "./assets/images/spring/cherry_blossom.jpg",
            "./assets/images/spring/iris.jpg",
            "./assets/images/spring/daisy.jpg",
            "./assets/images/spring/lilac.jpg",
            "./assets/images/spring/pansy.jpg",
            "./assets/images/spring/hyacinth.jpg",
            "./assets/images/spring/magnolia.jpg",
            "./assets/images/spring/lily.jpg"
        ],
        game2: [ // Summer farm images
            "./assets/images/summerCards/lemon.svg",
            "./assets/images/summerCards/pears.svg",
            "./assets/images/summerCards/beetroot.svg",
            "./assets/images/summerCards/avocado.svg",
            "./assets/images/summerCards/tomato.svg",
            "./assets/images/summerCards/sweetpatato.svg",
            "./assets/images/summerCards/carrot.svg",
            "./assets/images/summerCards/apple.svg",
            "./assets/images/summerCards/grapes.svg",
            "./assets/images/summerCards/strawbarry.svg",
            "./assets/images/summerCards/turnip.svg",
            "./assets/images/summerCards/daikon.svg",
            "./assets/images/summerCards/onion.svg",
        ],
        game3: [ // Fall farm images
            "./assets/images/fall/pumpkin.jpg",
            "./assets/images/fall/apple.jpg",
            "./assets/images/fall/maple_leaf.jpg",
            "./assets/images/fall/acorn.jpg",
            "./assets/images/fall/wheat.jpg",
            "./assets/images/fall/corn.jpg",
            "./assets/images/fall/grape.jpg",
            "./assets/images/fall/mushroom.jpg",
            "./assets/images/fall/chrysanthemum.jpg",
            "./assets/images/fall/squash.jpg"
        ],
        game4: [ // Winter farm images
            "./assets/images/winter/snowflake.jpg",
            "./assets/images/winter/pine_cone.jpg",
            "./assets/images/winter/holly.jpg",
            "./assets/images/winter/mistletoe.jpg",
            "./assets/images/winter/winter_berry.jpg",
            "./assets/images/winter/evergreen.jpg",
            "./assets/images/winter/icicle.jpg",
            "./assets/images/winter/frost_leaf.jpg",
            "./assets/images/winter/snow_covered_pine.jpg",
            "./assets/images/winter/cardinal.jpg"
        ]
    };

    // Select the appropriate image set based on the current game
    const images = seasonImages[game];

    let cardValues = [];
    for (let i = 0; i < totalCards / 2; i++) {
        cardValues.push(images[i]);
        cardValues.push(images[i]);
    }
    cardValues = cardValues.sort(() => Math.random() - 0.5);

    let selectedCards = [];
    let matchedCards = [];
    let cards = [];

    // Start the timer
    startTimer();

    for (let value of cardValues) {
        const card = document.createElement("div");
        card.classList.add("card");
        card.dataset.value = value;
        const cardInner = document.createElement("div");
        cardInner.classList.add("card-inner");
        const cardFront = document.createElement("div");
        cardFront.classList.add("card-front");
        cardFront.style.display = "flex";
        cardFront.style.alignItems = "center";
        cardFront.style.justifyContent = "center";
        cardFront.style.fontSize = "2em";
        cardFront.style.color = "#333";
        cardFront.style.fontWeight = "bold";
        cardFront.style.borderRadius = "10px";
        cardFront.style.border = "1px solid #ddd";
        cardFront.style.backgroundColor = "transparent";
        
        // Create back card image instead of text
        const backImg = document.createElement("img");
        backImg.src = "./assets/images/cardBack.svg";
        backImg.alt = "Card Back";
        backImg.style.width = "100%";
        backImg.style.height = "100%";
        backImg.style.objectFit = "cover";
        backImg.style.padding = "0";
        cardFront.appendChild(backImg);

        const cardBack = document.createElement("div");
        cardBack.classList.add("card-back");
        const img = document.createElement("img");
        img.src = value;
        img.alt = "Card Image";
        img.style.width = "100%";
        img.style.height = "100%";
        cardBack.appendChild(img);
        cardInner.appendChild(cardFront);
        cardInner.appendChild(cardBack);
        card.appendChild(cardInner);
        cards.push(card);

        card.addEventListener("click", function () {
            if (matchedCards.includes(card) || selectedCards.length >= 2) return;

            // Increment move count
            moveCount++;
            updateMoveCounter();

            card.classList.add("flipped");
            selectedCards.push(card);
            if (selectedCards.length === 2) {
                setTimeout(() => {
                    if (selectedCards[0].dataset.value === selectedCards[1].dataset.value) {
                        selectedCards.forEach(c => c.classList.add("matched"));
                        matchedCards.push(...selectedCards);

                        // Add matched image to a basket
                        addToBasket(selectedCards[0].dataset.value);

                    } else {
                        selectedCards.forEach(c => c.classList.remove("flipped"));
                    }
                    selectedCards = [];

                    if (matchedCards.length === totalCards) {
                        setTimeout(() => {
                            // Stop the timer
                            stopTimer();

                            // Add reward for the completed level
                            rewards[currentGame][currentLevel - 1] = `Reward ${currentLevel}`;
                            updateRewardsOnBothPages();

                            // Show win popup with stats
                            showWinPopup();
                        }, 500);
                    }
                }, 1000);
            }
        });
        gameBoard.appendChild(card);
    }

    // Preview all cards before gameplay starts
    cards.forEach(card => card.classList.add("flipped"));
    setTimeout(() => {
        cards.forEach(card => card.classList.remove("flipped"));
    }, 2000);

    // Update rewards on both pages when starting the game
    updateRewardsOnBothPages();
}

function addToBasket(imageSrc) {
    const baskets = document.querySelectorAll('.basket img');
    if (basketIndex < 2) {
        baskets[basketIndex].src = imageSrc;
        basketIndex++;
    } else {
        // Reset baskets if both are full
        baskets.forEach(basket => basket.src = "");
        basketIndex = 0;
        baskets[basketIndex].src = imageSrc;
        basketIndex++;
    }
}

function startTimer() {
    elapsedTime = 0;
    clearInterval(timerInterval);
    timerInterval = setInterval(() => {
        elapsedTime++;
        const minutes = Math.floor(elapsedTime / 60).toString().padStart(2, '0');
        const seconds = (elapsedTime % 60).toString().padStart(2, '0');
        document.getElementById('timer').innerText = `${minutes}:${seconds}`;
    }, 1000);
}

function stopTimer() {
    clearInterval(timerInterval);
}

function resetGameStats() {
    stopTimer();
    elapsedTime = 0;
    moveCount = 0;
    basketIndex = 0; // Reset basket index
    document.getElementById('timer').innerText = '00:00';
    document.getElementById('popupTimer').innerText = '00:00';
    document.getElementById('popupMoves').innerText = '0';
    document.querySelectorAll('.basket img').forEach(basket => basket.src = ""); // Clear baskets
}

function updateMoveCounter() {
    document.getElementById('popupMoves').innerText = moveCount;
}

function updateRewardsOnBothPages() {
    // Update rewards on the level selection page
    const levelPagePlaceholders = document.querySelectorAll(`#${currentGame}Page .reward-placeholder`);
    rewards[currentGame].forEach((reward, index) => {
        levelPagePlaceholders[index].innerText = reward || "Reward " + (index + 1);
        levelPagePlaceholders[index].style.backgroundColor = reward ? "#4caf50" : "#ccc";
    });

    // Update rewards on the game board page
    const gameBoardPlaceholders = document.querySelectorAll('#gameBoardContainer .reward-placeholder');
    rewards[currentGame].forEach((reward, index) => {
        gameBoardPlaceholders[index].innerText = reward || "Reward " + (index + 1);
        gameBoardPlaceholders[index].style.backgroundColor = reward ? "#4caf50" : "#ccc";
    });
}

function showWinPopup() {
    const minutes = Math.floor(elapsedTime / 60).toString().padStart(2, '0');
    const seconds = (elapsedTime % 60).toString().padStart(2, '0');
    document.getElementById('popupTimer').innerText = `${minutes}:${seconds}`;
    document.getElementById('popupMoves').innerText = moveCount;
    document.getElementById('winPopupContainer').style.display = 'flex';
}

function nextLevel() {
    document.getElementById('winPopupContainer').style.display = 'none';
    if (currentLevel < 3) {
        currentLevel++;
        startGame(currentRows + 1, currentCols + 1, currentGame, currentLevel);
    } else {
        showFinalWinPopup();
    }
}

function exitGame() {
    document.getElementById('winPopupContainer').style.display = 'none';
    goBackToGamePage();
}

function goBackToGamePage() {
    document.getElementById('gameBoardContainer').style.display = 'none';
    document.getElementById(`${currentGame}Page`).style.display = 'block';
}

function showFinalWinPopup() {
    document.getElementById('finalWinPopupContainer').style.display = 'flex';
    // Add your final reward image here
    document.getElementById('finalWinImage').src = "./assets/images/final-reward.jpg"; // Update this path
}

function closeWinPopup() {
    const popup = document.getElementById('winPopupContainer');
    if (popup) {
        popup.style.display = 'none';
    }
}

function closeFinalWinPopup() {
    const popup = document.getElementById('finalWinPopupContainer');
    if (popup) {
        popup.style.display = 'none';
    }
}