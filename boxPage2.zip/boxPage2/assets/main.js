let currentRows, currentCols;

function startGame(rows, cols) {
    currentRows = rows;
    currentCols = cols;

    document.getElementById('home').style.display = 'none';
    document.getElementById('gamePage').style.display = 'block';

    const totalCards = rows * cols;
    if (totalCards % 2 !== 0) {
        
        return;
    }

    const gameBoard = document.getElementById("gameBoard");
    gameBoard.innerHTML = "";
    gameBoard.style.gridTemplateColumns = `repeat(${cols}, 80px)`;
    gameBoard.style.gridTemplateRows = `repeat(${rows}, 100px)`;

    let cardValues = [];
    for (let i = 1; i <= totalCards / 2; i++) {
        cardValues.push(i);
        cardValues.push(i);
    }

    cardValues = cardValues.sort(() => Math.random() - 0.5);

    let selectedCards = [];
    let matchedCards = [];
    let cards = [];

    for (let value of cardValues) {
        const card = document.createElement("div");
        card.classList.add("card");
        card.dataset.value = value;

        const cardInner = document.createElement("div");
        cardInner.classList.add("card-inner");

        const cardFront = document.createElement("div");
        cardFront.classList.add("card-front");
        cardFront.innerText = "?"; 

        const cardBack = document.createElement("div");
        cardBack.classList.add("card-back");
        cardBack.innerText = value;

        cardInner.appendChild(cardFront);
        cardInner.appendChild(cardBack);
        card.appendChild(cardInner);

        cards.push(card);
        card.classList.add("flipped"); 

        card.addEventListener("click", function () {
            if (matchedCards.includes(card) || selectedCards.includes(card)) return;

            card.classList.add("flipped");
            selectedCards.push(card);

            if (selectedCards.length === 2) {
                setTimeout(() => {
                    if (selectedCards[0].dataset.value === selectedCards[1].dataset.value) {
                        selectedCards.forEach(c => c.classList.add("matched"));
                        matchedCards.push(...selectedCards);
                    } else {
                        selectedCards.forEach(c => c.classList.remove("flipped"));
                    }
                    selectedCards = [];
                    
                    if (matchedCards.length === totalCards) {
                        setTimeout(showWinPopup, 500);
                    }
                }, 1000);
            }
        });

        gameBoard.appendChild(card);
    }

    setTimeout(() => {
        cards.forEach(card => card.classList.remove("flipped"));
    }, 2000);
}

function showWinPopup() {
    let popup = document.getElementById('winPopupContainer');
    popup.style.display = 'flex';
}

function exitGame() {
    document.getElementById('winPopupContainer').style.display = 'none';
    goBack();
}

function nextLevel() {
    document.getElementById('winPopupContainer').style.display = 'none';

    if (currentRows <= currentCols) {
        currentRows++;
    } else {
        currentCols++;
    }

    startGame(currentRows, currentCols+1);
}

function goBack() {
    document.getElementById('home').style.display = 'flex';
    document.getElementById('gamePage').style.display = 'none';
}
