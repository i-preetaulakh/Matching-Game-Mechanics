let currentRows, currentCols, currentGame, currentLevel = 1;
const rewards = { game1: [], game2: [], game3: [], game4: [] };

// Timer variables
let timerInterval, elapsedTime = 0;

// Move counter variable
let moveCount = 0;

// Basket tracking
let basketIndex = 0; // Tracks which basket to use (0 or 1)

function goToGame(game) {
    document.getElementById('landingPage').style.display = 'none';
    document.getElementById(`${game}Page`).style.display = 'block';
    currentGame = game;
}

function goBackToLanding() {
    document.querySelectorAll('.game-page').forEach(page => page.style.display = 'none');
    document.getElementById('landingPage').style.display = 'flex';
    document.getElementById('winPopupContainer').style.display = 'none';
    document.getElementById('finalWinPopupContainer').style.display = 'none';
    currentGame = null;
    currentLevel = 1;
    resetGameStats();
}

function startGame(rows, cols, game, level) {
    currentRows = rows;
    currentCols = cols;
    currentGame = game;
    currentLevel = level;

    // Reset game stats for new level
    resetGameStats();

    document.getElementById(`${game}Page`).style.display = 'none';
    document.getElementById('gameBoardContainer').style.display = 'block';

    const totalCards = rows * cols;
    if (totalCards % 2 !== 0) return;

    const gameBoard = document.getElementById("gameBoard");
    gameBoard.innerHTML = "";
    gameBoard.style.gridTemplateColumns = `repeat(${cols}, 80px)`;
    gameBoard.style.gridTemplateRows = `repeat(${rows}, 100px)`;

    const images = [
        "./assets/images/apple.jpg",
        "./assets/images/orange.jpg",
        "./assets/images/lemon.jpeg",
        "./assets/images/mango.jpg",
        "./assets/images/peach.jpg",
        "./assets/images/avocado.jpg",
        "./assets/images/pear.jpg",
        "./assets/images/kiwi.jpg",
        "./assets/images/strawberry.jpeg",
        "./assets/images/melon.jpg"
    ];

    let cardValues = [];
    for (let i = 0; i < totalCards / 2; i++) {
        cardValues.push(images[i]);
        cardValues.push(images[i]);
    }
    cardValues = cardValues.sort(() => Math.random() - 0.5);

    let selectedCards = [];
    let matchedCards = [];
    let cards = [];

    // Start the timer
    startTimer();

    for (let value of cardValues) {
        const card = document.createElement("div");
        card.classList.add("card");
        card.dataset.value = value;
        const cardInner = document.createElement("div");
        cardInner.classList.add("card-inner");
        const cardFront = document.createElement("div");
        cardFront.classList.add("card-front");
        cardFront.innerText = "?";
        const cardBack = document.createElement("div");
        cardBack.classList.add("card-back");
        const img = document.createElement("img");
        img.src = value;
        img.alt = "Card Image";
        img.style.width = "100%";
        img.style.height = "100%";
        cardBack.appendChild(img);
        cardInner.appendChild(cardFront);
        cardInner.appendChild(cardBack);
        card.appendChild(cardInner);
        cards.push(card);

        card.addEventListener("click", function () {
            if (matchedCards.includes(card) || selectedCards.length >= 2) return;

            // Increment move count
            moveCount++;
            updateMoveCounter();

            card.classList.add("flipped");
            selectedCards.push(card);
            if (selectedCards.length === 2) {
                setTimeout(() => {
                    if (selectedCards[0].dataset.value === selectedCards[1].dataset.value) {
                        selectedCards.forEach(c => c.classList.add("matched"));
                        matchedCards.push(...selectedCards);

                        // Add matched image to a basket
                        addToBasket(selectedCards[0].dataset.value);

                    } else {
                        selectedCards.forEach(c => c.classList.remove("flipped"));
                    }
                    selectedCards = [];

                    if (matchedCards.length === totalCards) {
                        setTimeout(() => {
                            // Stop the timer
                            stopTimer();

                            // Add reward for the completed level
                            rewards[currentGame][currentLevel - 1] = `Reward ${currentLevel}`;
                            updateRewardsOnBothPages();

                            // Show win popup with stats
                            showWinPopup();
                        }, 500);
                    }
                }, 1000);
            }
        });
        gameBoard.appendChild(card);
    }

    // Preview all cards before gameplay starts
    cards.forEach(card => card.classList.add("flipped"));
    setTimeout(() => {
        cards.forEach(card => card.classList.remove("flipped"));
    }, 2000);

    // Update rewards on both pages when starting the game
    updateRewardsOnBothPages();
}

function addToBasket(imageSrc) {
    const baskets = document.querySelectorAll('.basket img');
    if (basketIndex < 2) {
        baskets[basketIndex].src = imageSrc;
        basketIndex++;
    } else {
        // Reset baskets if both are full
        baskets.forEach(basket => basket.src = "");
        basketIndex = 0;
        baskets[basketIndex].src = imageSrc;
        basketIndex++;
    }
}

function startTimer() {
    elapsedTime = 0;
    clearInterval(timerInterval);
    timerInterval = setInterval(() => {
        elapsedTime++;
        const minutes = Math.floor(elapsedTime / 60).toString().padStart(2, '0');
        const seconds = (elapsedTime % 60).toString().padStart(2, '0');
        document.getElementById('timer').innerText = `${minutes}:${seconds}`;
    }, 1000);
}

function stopTimer() {
    clearInterval(timerInterval);
}

function resetGameStats() {
    stopTimer();
    elapsedTime = 0;
    moveCount = 0;
    basketIndex = 0; // Reset basket index
    document.getElementById('timer').innerText = '00:00';
    document.getElementById('popupTimer').innerText = '00:00';
    document.getElementById('popupMoves').innerText = '0';
    document.querySelectorAll('.basket img').forEach(basket => basket.src = ""); // Clear baskets
}

function updateMoveCounter() {
    document.getElementById('popupMoves').innerText = moveCount;
}

function updateRewardsOnBothPages() {
    // Update rewards on the level selection page
    const levelPagePlaceholders = document.querySelectorAll(`#${currentGame}Page .reward-placeholder`);
    rewards[currentGame].forEach((reward, index) => {
        levelPagePlaceholders[index].innerText = reward || "Reward " + (index + 1);
        levelPagePlaceholders[index].style.backgroundColor = reward ? "#4caf50" : "#ccc";
    });

    // Update rewards on the game board page
    const gameBoardPlaceholders = document.querySelectorAll('#gameBoardContainer .reward-placeholder');
    rewards[currentGame].forEach((reward, index) => {
        gameBoardPlaceholders[index].innerText = reward || "Reward " + (index + 1);
        gameBoardPlaceholders[index].style.backgroundColor = reward ? "#4caf50" : "#ccc";
    });
}

function showWinPopup() {
    const minutes = Math.floor(elapsedTime / 60).toString().padStart(2, '0');
    const seconds = (elapsedTime % 60).toString().padStart(2, '0');
    document.getElementById('popupTimer').innerText = `${minutes}:${seconds}`;
    document.getElementById('popupMoves').innerText = moveCount;
    document.getElementById('winPopupContainer').style.display = 'flex';
}

function nextLevel() {
    document.getElementById('winPopupContainer').style.display = 'none';
    if (currentLevel < 3) {
        currentLevel++;
        startGame(currentRows + 1, currentCols + 1, currentGame, currentLevel);
    } else {
        showFinalWinPopup();
    }
}

function exitGame() {
    document.getElementById('winPopupContainer').style.display = 'none';
    goBackToGamePage();
}

function goBackToGamePage() {
    document.getElementById('gameBoardContainer').style.display = 'none';
    document.getElementById(`${currentGame}Page`).style.display = 'block';
}

function showFinalWinPopup() {
    document.getElementById('finalWinPopupContainer').style.display = 'flex';
    // Add your final reward image here
    document.getElementById('finalWinImage').src = "./assets/images/final-reward.jpg"; // Update this path
}